#pragma once

#include <iostream>

class HelloWorld {
public:
	void print()
	{
		std::cout << "Hello, World!" << std::endl;
	};
};