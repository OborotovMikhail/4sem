#include <iostream>
#include <opencv/cv.hpp>
#include <opencv/highgui.h>

using namespace cv;

int main()
{
	return 0;
}