#include <iostream>
#include <SFML\Graphics.hpp>

#include "debug.h"

int main()
{
    

    return 0;
}