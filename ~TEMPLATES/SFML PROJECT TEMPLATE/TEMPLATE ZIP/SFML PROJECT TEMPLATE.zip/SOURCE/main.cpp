#include <iostream>
#include <SFML\Graphics.hpp>

int main()
{
   

    return 0;
}